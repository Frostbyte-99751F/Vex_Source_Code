
#include "vex.h"

using namespace vex;
competition comp;

void dc(){
  
  dt.setStopping(coast);
  task d1(driverTank);
  wait(10, msec);

}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  comp.drivercontrol(dc);
  comp.autonomous(mainAuton);
  
}
