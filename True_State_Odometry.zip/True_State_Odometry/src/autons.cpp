#include "vex.h"
using namespace vex;

void mainAuton() {

}