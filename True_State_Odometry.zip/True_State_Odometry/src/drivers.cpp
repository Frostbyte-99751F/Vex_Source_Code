#include "vex.h"

using namespace vex;

double velF = 75;
double velI = 100;
double o;

int distanceWanted;

bool enableAutonTasks;
bool latch;
int timeOld;
int timeNew;
int deltaTime;
double leftSpeedF;
double leftSpeedM;
double leftSpeedB;
double rightSpeedF;
double rightSpeedM;
double rightSpeedB;

double leftSpd;
double rightSpd;

double inertStandIn = 0;
double rotaStandIn = 0;

double x = 0;
double y = 0;

double halfTile(double dist){
  return 0 * dist;
}

double inertPos(){
  return inert.rotation(degrees) - inertStandIn;
}

double rotaPos(){
  return rota.position(degrees) - rotaStandIn;
}

double trueRota(){
  return rota.position(degrees);
}

double trueInert(){
  return inert.rotation(degrees);
}

//////////////////////////////////////
/// - - - VARIABLE FUNCTIONS - - - ///

void reset(){
  inertStandIn = trueInert();
  rotaStandIn = trueRota();
}

double calcX(){
  double temp = (rotaPos() / 90) * sin(90-inertPos());
  return temp + x;
}

double calcY(){
  double temp = (rotaPos() / 90)  * sin(inertPos());
  return temp + y;
}

void calcPos(){
  x = calcX();
  y = calcY();
}

double turnSpd(double deg) {
  if (fabs(deg) >= fabs(inertPos()) + 3 &&
      (fabs((deg - inertPos()) / 1.8)) > 4.5)
    return (fabs((deg - inertPos()) / 1.8) * 1.35);
  else
    return 4.5;
}

double driveSpd(double dist) {
  if (fabs((dist - inertPos())) / 4 > 100)
    return 100;
  else
    return fabs((dist - inertPos())) / 4.8;
}

///////////////////////////////////////////////
/// - - - AUTONOMOUS/DRIVER FUNCTIONS - - - ///

// MOVEMENT

void tank(double lspd, double rspd) {
  leftSide.spin(forward, lspd, pct);
  rightSide.spin(reverse, rspd, pct);
}

void reducedTurnTo(double deg) {
  inert.setRotation(0, degrees);
  while (deg <= inertPos() - 0.19 ||
         deg >= inertPos() + 0.19) {
    double spd = turnSpd(deg);
    if (deg < inertPos() - 0.19) {
      tank(-spd, spd);
      wait(10, msec);
      dt.stop(hold);
    }
    if (deg > inertPos() + 0.19) {
      tank(spd, -spd);
      wait(10, msec);
      dt.stop(hold);
    }
  }
  dt.stop(hold);
}

void goTo(double spd, double dist) {

  int dir = fabs(dist) / dist;
  distanceWanted = dist;
  reset();

  if (dir > 0) {

    while (rota.position(deg) < dist) {
      tank((driveSpd(dist) * dir) - inertPos() * 1.2,
           (driveSpd(dist) * dir) + inertPos() * 1.2);
      wait(10, msec);
    }
    dt.stop(hold);
  } else if (dir < 0) {

    while (rota.position(deg) > dist) {
      tank((driveSpd(dist) * dir) - inertPos() * 1.2,
           (driveSpd(dist) * dir) + inertPos() * 1.2);
      wait(10, msec);
    }
    dt.stop(hold);
  }
  dt.stop(hold);
  calcPos();
}

////////////////////////////////////
/// - - - HELPER FUNCTIONS - - - ///

void pre_auton() {
  inert.calibrate();
  while (inert.isCalibrating()) {
    wait(20, msec);
  }
  vexcodeInit();
}

///////////////////////////
/// - - - THREADS - - - ///

int driverTank() {
  dt.setStopping(coast);

  while (enableAutonTasks == false) {
    leftSide.spin(fwd, driver.Axis3.value(), pct);
    rightSide.spin(reverse, driver.Axis2.value(), pct);
    task::sleep(10);
  }
  return 0;
}
 