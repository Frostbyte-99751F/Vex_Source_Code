#include "vex.h"

using namespace vex;

brain Brain;

motor fleft(PORT15, true), bleft(PORT11, true), mleft(PORT4); 
motor fright(PORT19, true), bright(PORT3, true), mright(PORT7); 

inertial inert(PORT16);
rotation rota(PORT17, true);

motor_group dt(fleft, bleft, mleft,fright,bright,mright), 
            leftSide(fleft, bleft, mleft), 
            rightSide(fright, bright, mright); 

controller driver;


double wheelTravel = 4 * M_PI; 

void vexcodeInit(void) {
  inert.calibrate();
  while(inert.isCalibrating()){
    wait(20,msec);
  }
}