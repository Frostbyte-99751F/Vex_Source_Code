using namespace vex;


//MOTORS
extern motor fright, mright, bright, fleft, mleft, bleft;
extern motor_group dt, leftSide, rightSide;

//SENSORS
extern inertial inert;
extern rotation rota;
extern optical eye;

//MISC
extern controller driver;
extern brain Brain;


extern int driverTank();
extern void mainAuton();
extern void goTo(double spd, double dist);
extern double driveSpd(double dist);
extern void tank(double lspd, double rspd);
extern void reset();

void vexcodeInit(void);